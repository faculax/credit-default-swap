package com.vibe.fundsmith.model;

public enum TradeSide {
    BUY,
    SELL
}