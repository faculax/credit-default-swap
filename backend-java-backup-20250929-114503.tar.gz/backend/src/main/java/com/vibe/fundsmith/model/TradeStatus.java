package com.vibe.fundsmith.model;

public enum TradeStatus {
    NEW,
    AMENDED,
    CANCELED
}